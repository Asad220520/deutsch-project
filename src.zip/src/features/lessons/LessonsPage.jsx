export default function LessonsPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Уроки</h2>
      <p>Здесь будет список всех доступных уроков.</p>
    </div>
  );
}
