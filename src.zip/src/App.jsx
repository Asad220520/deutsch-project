import useAutoLogin from "./features/auth/useAutoLogin";
import AppRouter from "./router/AppRouter";
export default function App() {
  useAutoLogin();
  return <AppRouter />;
}
