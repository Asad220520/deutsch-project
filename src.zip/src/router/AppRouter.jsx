// src/router/AppRouter.jsx
import { Routes, Route } from "react-router-dom";
import Login from "../features/auth/LoginForm";
import Home from "../pages/Home";
import Profile from "../pages/Profile";
import LessonsPage from "../features/lessons/LessonsPage";
import NotFound from "../pages/NotFound";
import ProtectedRoute from "../components/common/ProtectedRoute";
import MainLayout from "../layout/MainLayout";
import AuthLayout from "../layout/AuthLayout";
import useAutoLogin from "../features/auth/useAutoLogin";
import AdminDashboard from "../pages/ AdminDashboard";
import AdminRoute from "../components/common/AdminRoute";

export default function AppRouter() {
  useAutoLogin()
  return (
    <Routes>
      <Route element={<AuthLayout />}>
        <Route path="/login" element={<Login />} />
      </Route>
      <Route
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Home />} />
        <Route path="/lessons" element={<LessonsPage />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
