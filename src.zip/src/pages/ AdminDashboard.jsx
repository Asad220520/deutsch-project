// src/pages/AdminDashboard.jsx
export default function AdminDashboard() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold">Админ-панель</h1>
      <p>Только для администраторов 👑</p>
    </div>
  );
}
